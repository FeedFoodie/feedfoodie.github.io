import random
import os
import tkinter as tk

#choose file dialog
from tkinter.filedialog import askopenfilename
tk.Tk().withdraw()
filename = askopenfilename()

#rename file to txt
base = os.path.splitext(filename)[0]
txtfile = base + '.txt'
os.rename(filename, txtfile)

#convert txt into list
with open(txtfile, "r", encoding='utf8') as f:
    contents = f.readlines()

#aggAnnoy list
aggAnnoy = ["aggAnnoy01\n\n", "aggAnnoy02\n\n", "aggAnnoy03\n\n", "aggAnnoy04\n\n", "aggAnnoy05\n\n", "aggAnnoy06\n\n", "aggAnnoy07\n\n", "aggAnnoy08\n\n", "aggAnnoy09\n\n", "aggAnnoy10\n\n", "aggAnnoy11\n\n", "aggAnnoy12\n\n", "aggAnnoy13\n\n", "aggAnnoy14\n\n", "aggAnnoy15\n\n", "aggAnnoy16\n\n", "aggAnnoy17\n\n", "aggAnnoy18\n\n", "aggAnnoy19\n\n", "aggAnnoy20\n\n"]

#randomly insert aggAnnoy into chapter
lines = random.randrange(10, 30, 2)
for x in range(10, len(contents)):
    if lines == 0: 
        annoyance = random.choice(aggAnnoy); contents.insert(x, annoyance); lines = random.randrange(10, 30, 2);
    else:
        lines  -= 1;

#export chapter to txt
with open(txtfile, "w", encoding='utf8') as f:
    contents = "".join(contents)
    f.write(contents)

#rename txt back to md
base = os.path.splitext(txtfile)[0]
os.rename(txtfile, base + '.md')